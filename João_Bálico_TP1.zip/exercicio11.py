# Exercício 11
# Escreva um código que funcione de acordo com o enunciado

# Faça um programa que somará dois números e mostrará a média desses números como resultado.

# Escreva seu código aqui

numero1 = int(input("Digite o primeiro número: "))
numero2 = int(input("Digite o segundo número: "))

soma = numero1 + numero2

media = soma / 2

print(media)